
   
  
      <footer id="footer" style=" text-align: center; margin-top:800px;">
      <h3> --- Follow Us on---</h3> <br>
       <a href=""> <i class="socialy fab fa-facebook-f fa-2x" style="margin: 20px 10px;color:blue;"></i></a>
       <a href=""><i class="socialy fab fa-instagram fa-2x"style="margin: 20px 10px ;color:red;"></i></a>
       <a href=""><i class="socialy fab fa-twitter fa-2x"style="margin: 20px 10px;"></i></a>
            <a href=""><i class="socialy fas fa-envelope fa-2x"style="margin: 20px 10px;color:yellow;"></i></a>
            <p>© Copyright 2022 ekart <br>
        Made with ❤ by Shubham Singh</p>
        
        </footer>
    
  
 <?php /**PATH /home/shubham/Desktop/8/eKart/resources/views/footer.blade.php ENDPATH**/ ?>